%Tugas 3 - Pemodelan Kedepan Inversi Linear Bola Homogen Gravitasi
%Leonardo Budhi Satrio Utomo
%12318011

clc
clear
close all

x = [100 300 650 950];
y = [200 600 200 800];
z = [150 200 100 200];
R = [100 100 100 100];
rho = [2000 9000 2000 5000];
G = 6.674.*10.^(-11);

x0 = (0:100:1000);
y0 = (0:100:1000);
[xi,yi] = meshgrid(0:100:1000, 0:100:1000); %m

%d = [((6.674*10.^(-11))*((4/3)*pi*R[1].^3*z[1])/((x[1]-x0).^2+(y-y0

g1 = [G.*(4/3).*pi.*z(1) G.*(4/3).*pi.*z(2) G.*(4/3).*pi.*z(3) G.*(4/3).*pi.*z(4)];
g2 = [1/((x(1)-(x0)').^2+(y(1)-(y0)').^2+(z(1)-(zeros(length(x0),1))).^2).^(3/2) 1/((x(2)-(x0)').^2+(y(2)-(y0)').^2+(z(2)-(zeros(length(x0),1))).^2).^(3/2) 1/((x(3)-x0').^2+(y(3)-(y0)').^2+(z(3)-(zeros(length(x0),1))).^2).^(3/2) 1/((x(4)-(x0)').^2+(y(4)-y0').^2+(z(4)-(zeros(length(x0),1))).^2).^(3/2)];

g = g1.*g2';
disp(size(g))
disp(size(rho'))
d = g*rho';

disp(size(d))
dnoise = d+0.05*randn(length(d),1);
disp(size(dnoise));
disp(size(xi));
di = reshape(dnoise,[11,4]);
disp(size(di));

contour3(xi,yi,di,150);%Plot dengan kontur dalam 3D
title('PEMODELAN PERSEBARAN NILAI GRAVITASI BOLA HOMOGEN PADA RUANG 3D DI PERMUKAAN')
xlabel('m')
ylabel('m')
zlabel('mGal')
hold on

%-----------------------------------------------------------------------------------------
% m = inv(G'*G)*G'*d;
% 
% dcal = G*m;
% plot


